Protocentral ADS1220 Library
============================

This is the Arduino library for the ADS1220 24-bit Sigma-Delta ADC breakout board.

You can buy the board using the following link:

http://www.protocentral.com/breakout-boards/773-ads1220-24-bit-4-channel-low-noise-adc-breakout-board.html
